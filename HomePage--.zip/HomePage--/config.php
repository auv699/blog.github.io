<?php

$site_name = "TryHarder_";
$name = "TryHarder_";
$description = "学，而知不足；教，然后知困！";
$keywords = "TryHarder,TryHarder主页,TryHarder引导页";
$left_tag = ["PHP",'Python','网瘾','Linux','后端开发'];

$QQ = 'https://qm.qq.com/cgi-bin/qm/qr?_wv=1027&k=kklZits7g6fCZUwpUtRbHWwAQbqpaiI6&authKey=XrvtlbmW1LhKXcbTOAVQHyhYnalmXzHUGHq2MVhn2NKJPmFLoTRAkh792riJYF3T&noverify=0&group_code=726109087';
$github = 'https://github.com/TryHarder-L';
$mail = 'tryharders@qq.com';

$left_des = [
    [
        'icon'  => 'Home',
        'desc'  => 'China GuangZhou'
    ],
    ];

$left_time = [
    "2024.7.14" => '退网时间线太长了 还不知道做了什么',
    "2023.8.24" => '开始搭建博客',
    ];

$site = [
    [
        'title' => '博客',
        'desc'  => '记录开发日常',
        'icon'  => 'book-open',
        'url'   => 'https://blog.lucksss.com/'
    ],
    [
        'title' => '其他',
        'desc'  => '还在发现新的稀奇古怪的玩意',
        'icon'  => 'fan',
        'url'   => '#'
    ],
];

$project = [
    [
        'title' => 'HomePage',
        'desc'  => '本主页源码',
        'icon'  => 'Home',
        'url'   => '#'
    ],
    [
        'title' => 'ProxyPool',
        'desc'  => '新一代代理采集器，高效、高可用、超简易拓展',
        'icon'  => 'rocket',
        'url'   => '#'
    ],
    [
        'title' => '其他',
        'desc'  => '还在发现新的稀奇古怪的玩意',
        'icon'  => 'fan',
        'url'   => '#'
    ],
    
];

$skill = [
    [
       'skill'  => 'PHP',
       'tip'    => '有啥系统开发都可以找我哦 快来单！',
       'rate'   => '80'
    ],
    [
       'skill'  => 'Python',
       'tip'    => '有啥爬虫啥都可以找我哦 快来单！',
       'rate'   => '60'
    ],
    [
       'skill'  => '社交',
       'tip'    => '社交牛逼症',
       'rate'   => '100'
    ],
    // [
    //   'skill'  => '恋爱',
    //   'tip'    => '已经有了有个很爱很爱的小公主啦',
    //   'rate'   => '100'
    // ],
    ];

?>

